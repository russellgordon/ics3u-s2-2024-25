import PlaygroundSupport
import SwiftUI

struct FirstLayout: View {
    
    // MARK: Computed properties
    var body: some View {
        
    }
    
}

PlaygroundPage.current.setLiveView(FirstLayout())
